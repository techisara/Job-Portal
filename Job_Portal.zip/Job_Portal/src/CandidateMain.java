import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Scanner;

public class CandidateMain {

	public static void main(String[] args) {
      ArrayList<Candidate> al = new ArrayList<Candidate>();
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter the number of employee you want to enter");
      int n = sc.nextInt();
      for (int i = 1; i <=n; i++) {
    	  Candidate c = new Candidate();
    	  System.out.println("Enter details of Emplyoee "+i);
    	  System.out.println("Enter candidate name");
    	  c.setName(sc.next());
    	  System.out.println("Enter candidate year of pass out");
    	  c.setYearOfPassOut(sc.nextInt());
    	  System.out.println("Enter candidate percentage");
    	  c.setPercentage(sc.nextInt());
    	  al.add(c);
    	  
    	  
    	  c=null;
		
	}
		//System.out.println(al);
      
      System.out.println("List of candidte who are eligiable to join the company");
		
		ListIterator<Candidate> itr = al.listIterator();

		while(itr.hasNext()) {
			Candidate c1 = itr.next();
			if(c1.getYearOfPassOut()==2020) {
              System.out.println(c1);
		}
			c1=null;
		
	}

	}
}
